package com.example.storyapp.data.remote

data class RegisterResponse(
    val error: Boolean,
    val message: String
)