package com.example.storyapp

object Log {
    @JvmStatic
    fun isLoggable(tag: String?, level: Int): Boolean {
        return true
    }
}